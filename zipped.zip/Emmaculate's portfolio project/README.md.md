# Personal Portfolio Website

## 📌 Project Overview
This is a personal portfolio website created using **HTML and CSS**. It showcases personal details, skills, and favorite meals, following a **consistent pink theme** for a visually appealing experience.

## 📂 Folder Structure
```
Portfolio-Website/
│── index.html (Homepage)
│── about.html (About Page)
│── recipe1.html (Pilau Recipe Page)
│── recipe2.html (Chicken Recipe Page)
│── styles/
│   ├── main.css (Main styling file)
│── images/
│   ├── profile.jpg
│   ├── pilau.jpg
│   ├── chicken.jpg
```

## 🚀 How to Navigate the Website

- **Homepage (Homepage.html)** – Welcome message, introduction, and navigation links.
- **About Page (Aboutpage.html)** – Profile picture, biography, and skills.
- **Recipe Pages** – Step-by-step guides for pilau and chicken recipes.
- **Navigation Bar** – Easily switch between pages.

## 🎨 Features
✅ **Fully responsive design**  
✅ **Consistent pink theme**  
✅ **Simple, easy-to-navigate UI**  
✅ **Cross-browser compatibility**  

## 🔧 How to Run the Website
1. **Extract the ZIP file** (if downloaded).  
2. **Open `index.html`** in a web browser.  
3. **Navigate using the menu** to explore different pages.  

## ✅ Validation Instructions
- **HTML Validation:** Use the [W3C HTML Validator](https://validator.w3.org/)  
- **CSS Validation:** Use the [W3C CSS Validator](https://jigsaw.w3.org/css-validator/)  

## 📩 Contact Information
For any questions or improvements, feel free to reach out!  

**Author:** Emmaculate Mumbi  
**Year:** 2025  
**License:** Free for personal use.  
